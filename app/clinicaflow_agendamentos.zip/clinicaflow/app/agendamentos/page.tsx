"use client";

import { useState } from "react";
import Link from "next/link";

const agendamentos = [
  { id: 1, hora: "08:00", paciente: "Ana Silva", tipo: "Consulta", status: "confirmado", data: "15/05/2026", telefone: "(11) 99999-0001" },
  { id: 2, hora: "09:30", paciente: "Carlos Mendes", tipo: "Retorno", status: "confirmado", data: "15/05/2026", telefone: "(11) 99999-0002" },
  { id: 3, hora: "10:00", paciente: "Maria Santos", tipo: "Consulta", status: "pendente", data: "15/05/2026", telefone: "(11) 99999-0003" },
  { id: 4, hora: "11:00", paciente: "João Oliveira", tipo: "Exame", status: "confirmado", data: "15/05/2026", telefone: "(11) 99999-0004" },
  { id: 5, hora: "14:00", paciente: "Fernanda Costa", tipo: "Consulta", status: "pendente", data: "15/05/2026", telefone: "(11) 99999-0005" },
  { id: 6, hora: "15:30", paciente: "Roberto Lima", tipo: "Retorno", status: "confirmado", data: "15/05/2026", telefone: "(11) 99999-0006" },
  { id: 7, hora: "09:00", paciente: "Juliana Pereira", tipo: "Consulta", status: "confirmado", data: "16/05/2026", telefone: "(11) 99999-0007" },
  { id: 8, hora: "10:30", paciente: "Ricardo Alves", tipo: "Retorno", status: "pendente", data: "16/05/2026", telefone: "(11) 99999-0008" },
];

const dias = ["15/05", "16/05", "17/05", "18/05", "19/05"];

export default function Agendamentos() {
  const [diaSelecionado, setDiaSelecionado] = useState("15/05");
  const [showModal, setShowModal] = useState(false);

  const filtrados = agendamentos.filter(a => a.data.startsWith(diaSelecionado));

  return (
    <div style={{
      minHeight: "100vh",
      background: "#080C14",
      fontFamily: "'DM Sans', sans-serif",
      color: "#E8EDF5",
    }}>
      <header style={{
        padding: "20px 32px",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
          <Link href="/dashboard" style={{ color: "#6B7280", textDecoration: "none", fontSize: "14px" }}>← Dashboard</Link>
          <h1 style={{ margin: 0, fontSize: "20px", fontWeight: "700" }}>📅 Agendamentos</h1>
        </div>
        <button onClick={() => setShowModal(true)} style={{
          background: "linear-gradient(135deg, #00FF87, #00C6FF)",
          border: "none",
          borderRadius: "10px",
          padding: "10px 20px",
          cursor: "pointer",
          color: "#080C14",
          fontWeight: "700",
          fontSize: "13px",
        }}>+ Novo Agendamento</button>
      </header>

      <div style={{ padding: "32px" }}>
        {/* Dias da semana */}
        <div style={{ display: "flex", gap: "10px", marginBottom: "28px" }}>
          {dias.map(dia => (
            <button key={dia} onClick={() => setDiaSelecionado(dia)} style={{
              padding: "10px 20px",
              borderRadius: "10px",
              border: diaSelecionado === dia ? "1px solid rgba(0,255,135,0.3)" : "1px solid rgba(255,255,255,0.08)",
              background: diaSelecionado === dia ? "rgba(0,255,135,0.1)" : "transparent",
              color: diaSelecionado === dia ? "#00FF87" : "#6B7280",
              cursor: "pointer",
              fontSize: "14px",
              fontWeight: "600",
            }}>{dia === "15/05" ? `${dia} • Hoje` : dia}</button>
          ))}
        </div>

        {/* Lista */}
        <div style={{
          background: "linear-gradient(135deg, #0D1421, #111827)",
          border: "1px solid rgba(255,255,255,0.06)",
          borderRadius: "16px",
          overflow: "hidden",
        }}>
          {filtrados.length === 0 ? (
            <div style={{ padding: "60px", textAlign: "center", color: "#4A5568" }}>
              <div style={{ fontSize: "48px", marginBottom: "12px" }}>📅</div>
              <p>Nenhum agendamento para este dia</p>
            </div>
          ) : filtrados.map((ag, i) => (
            <div key={ag.id} style={{
              display: "flex",
              alignItems: "center",
              gap: "20px",
              padding: "18px 24px",
              borderBottom: i < filtrados.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none",
              transition: "background 0.2s",
              cursor: "pointer",
            }}
              onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.02)"}
              onMouseLeave={e => e.currentTarget.style.background = "transparent"}
            >
              <div style={{
                fontSize: "15px",
                fontWeight: "800",
                color: "#00C6FF",
                width: "56px",
                flexShrink: 0,
              }}>{ag.hora}</div>

              <div style={{
                width: "40px",
                height: "40px",
                borderRadius: "50%",
                background: "linear-gradient(135deg, #00FF87, #00C6FF)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "13px",
                fontWeight: "700",
                color: "#080C14",
                flexShrink: 0,
              }}>
                {ag.paciente.split(" ").map(n => n[0]).join("").slice(0, 2)}
              </div>

              <div style={{ flex: 1 }}>
                <div style={{ fontSize: "15px", fontWeight: "600" }}>{ag.paciente}</div>
                <div style={{ fontSize: "12px", color: "#6B7280" }}>{ag.telefone}</div>
              </div>

              <span style={{
                fontSize: "12px",
                padding: "5px 12px",
                borderRadius: "8px",
                background: "rgba(0,198,255,0.1)",
                color: "#00C6FF",
                border: "1px solid rgba(0,198,255,0.2)",
                fontWeight: "600",
              }}>{ag.tipo}</span>

              <span style={{
                fontSize: "12px",
                fontWeight: "600",
                padding: "5px 12px",
                borderRadius: "20px",
                background: ag.status === "confirmado" ? "rgba(0,255,135,0.1)" : "rgba(255,193,7,0.1)",
                color: ag.status === "confirmado" ? "#00FF87" : "#FFD700",
                border: `1px solid ${ag.status === "confirmado" ? "rgba(0,255,135,0.2)" : "rgba(255,193,7,0.2)"}`,
              }}>
                {ag.status === "confirmado" ? "✓ Confirmado" : "⏳ Pendente"}
              </span>

              <div style={{ display: "flex", gap: "8px" }}>
                <button style={{
                  background: "rgba(0,255,135,0.1)",
                  border: "1px solid rgba(0,255,135,0.2)",
                  borderRadius: "8px",
                  padding: "6px 12px",
                  cursor: "pointer",
                  color: "#00FF87",
                  fontSize: "12px",
                }}>📱 WhatsApp</button>
                <button style={{
                  background: "rgba(255,255,255,0.05)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: "8px",
                  padding: "6px 12px",
                  cursor: "pointer",
                  color: "#9CA3AF",
                  fontSize: "12px",
                }}>✏️</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div style={{
          position: "fixed", inset: 0,
          background: "rgba(0,0,0,0.7)",
          display: "flex", alignItems: "center", justifyContent: "center",
          zIndex: 100, backdropFilter: "blur(4px)",
        }}>
          <div style={{
            background: "#0D1421",
            border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: "20px",
            padding: "32px",
            width: "480px",
          }}>
            <h2 style={{ margin: "0 0 24px", fontSize: "20px", fontWeight: "700" }}>Novo Agendamento</h2>
            <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
              {["Paciente", "Data", "Horário", "Tipo de consulta"].map(label => (
                <div key={label}>
                  <label style={{ fontSize: "12px", fontWeight: "600", color: "#6B7280", marginBottom: "6px", display: "block" }}>{label}</label>
                  <input style={{
                    width: "100%", background: "rgba(255,255,255,0.04)",
                    border: "1px solid rgba(255,255,255,0.08)", borderRadius: "10px",
                    padding: "12px 14px", color: "#E8EDF5", fontSize: "14px",
                    outline: "none", boxSizing: "border-box",
                  }} placeholder={label} />
                </div>
              ))}
              <div style={{ display: "flex", gap: "12px", marginTop: "8px" }}>
                <button onClick={() => setShowModal(false)} style={{
                  flex: 1, background: "rgba(255,255,255,0.05)",
                  border: "1px solid rgba(255,255,255,0.08)", borderRadius: "10px",
                  padding: "12px", cursor: "pointer", color: "#9CA3AF", fontSize: "14px",
                }}>Cancelar</button>
                <button style={{
                  flex: 1, background: "linear-gradient(135deg, #00FF87, #00C6FF)",
                  border: "none", borderRadius: "10px", padding: "12px",
                  cursor: "pointer", color: "#080C14", fontWeight: "700", fontSize: "14px",
                }}>Salvar</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
